/**
  ******************************************************************************
  * File Name          : I2C.c
  * Description        : This file provides code for the configuration
  *                      of the I2C instances.
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2018 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "i2c.h"

#include "gpio.h"

/* USER CODE BEGIN 0 */
#include "box.h"
#include "stdbool.h"
#include "sh2_hal.h"
#include "string.h"
#include "sh2_err.h"
/* USER CODE END 0 */

I2C_HandleTypeDef hi2c1;

/* I2C1 init function */
void MX_I2C1_Init(void)
{

  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x0090144A;
  hi2c1.Init.OwnAddress1 = 148;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Analogue filter 
    */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure Digital filter 
    */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 4) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

}

void HAL_I2C_MspInit(I2C_HandleTypeDef* i2cHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct;
  if(i2cHandle->Instance==I2C1)
  {
  /* USER CODE BEGIN I2C1_MspInit 0 */

  /* USER CODE END I2C1_MspInit 0 */
  
    /**I2C1 GPIO Configuration    
    PB6     ------> I2C1_SCL
    PB7     ------> I2C1_SDA 
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF1_I2C1;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    GPIO_InitStruct.Pin = GPIO_PIN_7;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF1_I2C1;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

    /* I2C1 clock enable */
    __HAL_RCC_I2C1_CLK_ENABLE();

    /* I2C1 interrupt Init */
    HAL_NVIC_SetPriority(I2C1_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(I2C1_IRQn);
  /* USER CODE BEGIN I2C1_MspInit 1 */

  /* USER CODE END I2C1_MspInit 1 */
  }
}

void HAL_I2C_MspDeInit(I2C_HandleTypeDef* i2cHandle)
{

  if(i2cHandle->Instance==I2C1)
  {
  /* USER CODE BEGIN I2C1_MspDeInit 0 */

  /* USER CODE END I2C1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_I2C1_CLK_DISABLE();
  
    /**I2C1 GPIO Configuration    
    PB6     ------> I2C1_SCL
    PB7     ------> I2C1_SDA 
    */
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_6|GPIO_PIN_7);

    /* I2C1 interrupt Deinit */
    HAL_NVIC_DisableIRQ(I2C1_IRQn);
  /* USER CODE BEGIN I2C1_MspDeInit 1 */

  /* USER CODE END I2C1_MspDeInit 1 */
  }
} 

/* USER CODE BEGIN 1 */
//---------------------------------------------------------------------
//	��������� ��� ������ ������ ��������� BNO080
extern I2C_str BNO_write;
extern I2C_str BNO_read;
//---------------------------------------------------------------------
int sh2_hal_block(void)
{
    //xSemaphoreTake(sh2Hal.blockSem, portMAX_DELAY);

    return SH2_OK;
}
//---------------------------------------------------------------------
int sh2_hal_unblock(void)
{
    //xSemaphoreGive(sh2Hal.blockSem);

    return SH2_OK;
} 
//---------------------------------------------------------------------
// Reset an SH-2 module (into DFU mode, if flag is true)
// The onRx callback function is registered with the HAL at the same time.
int sh2_hal_reset(bool dfuMode,
                  sh2_rxCallback_t *onRx,
                  void *cookie)
                          
{
    
    // Assert reset
    //sh2Hal.rstn(0);
    
    // Set BOOTN according to dfuMode
    //sh2Hal.bootn(dfuMode ? 0 : 1);

    // Wait for reset to take effect
    //vTaskDelay(RESET_DELAY); 
       
    // Deassert reset
    //sh2Hal.rstn(1);

    // If reset into DFU mode, wait until bootloader should be ready
    //if (dfuMode) {
    //    vTaskDelay(DFU_BOOT_DELAY);
    //}

    // Will need to reset the i2c peripheral after this.
    //i2cResetNeeded = true;
    
    return SH2_OK;
}
//--------------------------------------------------------------------- 
// Send data to SH-2
int sh2_hal_tx(uint8_t *pData, uint32_t len)
{
  // Do nothing if len is zero
    if (len == 0) 
        return SH2_OK;
    
		memcpy(BNO_write.Data, pData, len);
		I2C1->CR2 = 0;
	//	AUTOEND, NBYTES, BNO_ADDRESS, WRITE
		I2C1->CR2 |= (1<<25) | (len<<16) | (BNO_ADDR<<1);
	
		I2C1->CR1 = 0;
	//	ANF_ON, TC_ON (1<<6), TXIE, PE 
		I2C1->CR1 |= (1<<12) | (1<<6) | (1<<1) | 1;
	
		BNO_write.i = 0;
		I2C1->TXDR  = BNO_write.Data[0]; //	�������� ������ ����		
		
		I2C1->CR2 |= I2C_CR2_START; //	START
		
	//	wait for read packet	
		while ((I2C1->ISR & (1<<15)) == 0)	
			stop_20mks();	
		while ((I2C1->ISR & (1<<15)) != 0)	
			stop_20mks();	
		
  // Do tx, and return when done
    return SH2_OK;//i2cBlockingTx(sh2Hal.addr, pData, len);
}
//---------------------------------------------------------------------
// Initiate a read of <len> bytes from SH-2
// This is a blocking read, pData will contain read data on return
// if return value was SH2_OK.
int sh2_hal_rx(uint8_t* pData, uint32_t len)
{
// Do nothing if len is zero
  if (len == 0) 
    return SH2_OK;
    
	while (I2C1->ISR & (1<<15));	//	wait BUSY flag := 0
	I2C1->CR2 = 0;
//	AUTOEND, N BYTES,  READ, BNO080_ADDRESS,
	I2C1->CR2 |= (1<<25) | (len<<16) | (1<<10) | (BNO_ADDR<<1);	
	
	I2C1->CR1 = 0;
//	ANF_ON, TC_ON (1<<6), RXIE, PE 
	I2C1->CR1 |= (1<<12) | (1<<2) | 1;

	BNO_read.i = 0;	
	I2C1->CR2 |= I2C_CR2_START;
		
//	wait for read packet	
	while ((I2C1->ISR & (1<<15)) == 0)	
		stop_20mks();	
	while ((I2C1->ISR & (1<<15)) != 0)	
		stop_20mks();
	
	memcpy(pData,BNO_read.Data,len);	
	
// do rx and return when done
  return SH2_OK;//i2cBlockingRx(sh2Hal.addr, pData, len);
}

//---------------------------------------------------------------------

/* USER CODE END 1 */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
